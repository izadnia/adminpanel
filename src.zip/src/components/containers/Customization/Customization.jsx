import React from 'react'

function Customization() {
  return (
    <div>Customization</div>
  )
}

export default Customization